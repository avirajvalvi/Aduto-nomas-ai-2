package com.example.autovideo

import org.json.JSONArray
import org.json.JSONObject

data class Scene(val narration: String, val keywords: String)
data class Outline(val title: String, val description: String, val parts: List<String>)
data class Plan(val title: String, val description: String, val scenes: List<Scene>)

/** प्रॉम्प्ट -> रूपरेखा -> भाग-दर-भाग सीन (लंबे वीडियो के लिए 3-3 मिनट के टुकड़े) */
class Planner(
    private val gemini: Gemini,
    private val language: String,
    private val log: (String) -> Unit
) {
    fun plan(prompt: String, minutes: Int): Plan {
        val m = minutes.coerceIn(1, 60)
        val chunks = chunkCount(m)
        val words = wordsPerChunk(m, chunks)

        log("रूपरेखा बना रहा हूँ ($chunks भाग)...")
        val outline = retry(2) { parseOutline(gemini.json(outlinePrompt(prompt, m, chunks)), chunks) }

        val scenes = ArrayList<Scene>()
        var tail = ""
        for (i in 0 until chunks) {
            log("भाग ${i + 1}/$chunks लिख रहा हूँ...")
            val part = retry(2) {
                parseScenes(gemini.json(scenePrompt(prompt, outline, i, chunks, words, tail)))
            }
            scenes.addAll(part)
            tail = part.last().narration.takeLast(150)
        }
        return Plan(outline.title, outline.description, scenes)
    }

    private fun <T> retry(times: Int, block: () -> T): T {
        var last: Exception? = null
        repeat(times) {
            try {
                return block()
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("योजना बनाने में फेल")
    }

    private fun outlinePrompt(prompt: String, minutes: Int, chunks: Int): String = """
तुम एक YouTube वीडियो स्क्रिप्ट राइटर हो।
वीडियो का विषय/निर्देश: $prompt
भाषा: $language
कुल लंबाई: लगभग $minutes मिनट। इसे ठीक $chunks भागों में बाँटो, हर भाग लगभग $CHUNK_MINUTES मिनट का।
सिर्फ़ इस JSON में जवाब दो:
{"title": "आकर्षक शीर्षक", "description": "YouTube डिस्क्रिप्शन", "parts": ["भाग 1 में क्या होगा", "भाग 2 में क्या होगा"]}
"parts" में ठीक $chunks आइटम हों, हर एक छोटा वाक्य।
""".trimIndent()

    private fun scenePrompt(
        prompt: String, outline: Outline, i: Int, chunks: Int, words: Int, tail: String
    ): String {
        val edge = buildString {
            if (i == 0) append("शुरुआत एक दमदार हुक से करो। ")
            if (i > 0) append("पिछला भाग इस पर ख़त्म हुआ था: \"$tail\"। वहीं से आगे बढ़ो, कुछ दोहराओ मत। ")
            if (i == chunks - 1) append("अंत में छोटा निष्कर्ष दो।")
        }
        val outlineText = outline.parts.mapIndexed { n, p -> "${n + 1}. $p" }.joinToString("\n")
        val sceneCount = maxOf(3, words / 35)
        return """
वीडियो का विषय/निर्देश: $prompt
भाषा: $language
पूरी रूपरेखा:
$outlineText

अब सिर्फ़ भाग ${i + 1}/$chunks लिखो: "${outline.parts[i]}"
$edge
इस भाग में कुल लगभग $words शब्द बोले जाएँ, और इसे लगभग $sceneCount सीन में बाँटो। हर सीन में 25 से 40 शब्द हों।
हर सीन के लिए "keywords" में Pexels पर स्टॉक वीडियो खोजने के 2-3 अंग्रेज़ी शब्द दो (जैसे "city night traffic"), जो उस सीन की बात से मेल खाएँ।
सिर्फ़ बोले जाने वाले शब्द लिखो: कोई इमोजी, स्टेज निर्देश, सीन नंबर या ब्रैकेट नहीं।
सिर्फ़ इस JSON में जवाब दो:
{"scenes": [{"narration": "बोला जाने वाला टेक्स्ट", "keywords": "english search words"}]}
""".trimIndent()
    }

    companion object {
        const val CHUNK_MINUTES = 3
        const val WORDS_PER_MINUTE = 130

        fun chunkCount(minutes: Int): Int = maxOf(1, (minutes + CHUNK_MINUTES - 1) / CHUNK_MINUTES)

        fun wordsPerChunk(minutes: Int, chunks: Int): Int = maxOf(40, minutes * WORDS_PER_MINUTE / chunks)

        fun parseOutline(json: String, chunks: Int): Outline {
            val j = JSONObject(json)
            val arr = j.optJSONArray("parts") ?: JSONArray()
            val parts = ArrayList<String>()
            for (i in 0 until arr.length()) parts.add(arr.optString(i))
            while (parts.size < chunks) parts.add("कहानी को आगे बढ़ाओ")
            return Outline(
                j.optString("title").ifBlank { "AI वीडियो" },
                j.optString("description"),
                parts.take(chunks)
            )
        }

        fun parseScenes(json: String): List<Scene> {
            val root = if (json.trimStart().startsWith("[")) {
                JSONObject().put("scenes", JSONArray(json))
            } else {
                JSONObject(json)
            }
            val arr = root.optJSONArray("scenes") ?: throw RuntimeException("जवाब में scenes नहीं मिले")
            val out = ArrayList<Scene>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val n = o.optString("narration").trim()
                if (n.isEmpty()) continue
                out.add(Scene(n, o.optString("keywords").trim().ifBlank { "abstract background" }))
            }
            if (out.isEmpty()) throw RuntimeException("कोई सीन नहीं बना")
            return out
        }
    }
}
