package com.example.autovideo

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

/**
 * प्रॉम्प्ट -> Gemini स्क्रिप्ट (सीन) -> हर सीन की आवाज़ + Pexels क्लिप -> Media3 से एक MP4
 */
class PromptPipeline(
    private val ctx: Context,
    private val s: Map<String, String>,
    private val log: (String) -> Unit,
    private val status: (String) -> Unit
) {
    private fun v(k: String): String = s[k].orEmpty()

    private fun useEleven(): Boolean = v("voice_engine").equals("elevenlabs", ignoreCase = true)

    private fun makeVoice(): Voice =
        if (useEleven()) ElevenVoice(v("el_key"), v("el_voice"))
        else PhoneVoice(ctx, v("voice_locale").ifBlank { "hi-IN" })

    suspend fun run(prompt: String, minutes: Int, portrait: Boolean): File {
        val work = File(ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        val stock = File(ctx.cacheDir, "stock").apply { deleteRecursively(); mkdirs() }

        val voice = withContext(Dispatchers.Main) { makeVoice() }
        try {
            status("स्क्रिप्ट लिख रहा हूँ...")
            val plan = withContext(Dispatchers.IO) {
                Planner(
                    Gemini(v("gemini_key"), v("gemini_model")),
                    v("language").ifBlank { "हिंदी" },
                    log
                ).plan(prompt, minutes)
            }
            log("कुल ${plan.scenes.size} सीन। शीर्षक: ${plan.title}")

            val pexels = Pexels(v("pexels_key"), stock)
            val assets = ArrayList<SceneAsset>()
            var lastClip: Pair<File, Long>? = null
            for ((i, scene) in plan.scenes.withIndex()) {
                currentCoroutineContext().ensureActive()
                status("सीन ${i + 1}/${plan.scenes.size}: आवाज़ और क्लिप")
                val asset = withContext(Dispatchers.IO) {
                    buildScene(i, scene, voice, pexels, work, portrait, lastClip)
                }
                lastClip = asset.clip to asset.clipMs
                assets.add(asset)
                if ((i + 1) % 10 == 0) log("${i + 1} सीन तैयार")
            }

            val totalSec = assets.sumOf { it.audioMs } / 1000
            log("कुल लंबाई: ${totalSec / 60} मिनट ${totalSec % 60} सेकंड। अब वीडियो जोड़ रहा हूँ (फ़ोन पर समय लगेगा)...")
            val out = File(ctx.cacheDir, "video_${System.currentTimeMillis()}.mp4")
            val composition = VideoComposer.buildComposition(assets, portrait)
            VideoComposer.export(ctx, composition, out) { p -> status("वीडियो एक्सपोर्ट: $p%") }
            return out
        } finally {
            voice.close()
        }
    }

    private fun buildScene(
        i: Int,
        scene: Scene,
        voice: Voice,
        pexels: Pexels,
        work: File,
        portrait: Boolean,
        previous: Pair<File, Long>?
    ): SceneAsset {
        val audio = File(work, "a$i." + if (useEleven()) "mp3" else "wav")
        voice.speak(scene.narration, audio)
        val audioMs = MediaUtil.durationMs(audio)
        if (audioMs <= 0) throw RuntimeException("सीन ${i + 1} की आवाज़ खाली बनी")

        val (clip, clipMs) = findClip(scene.keywords, pexels, portrait)
            ?: previous
            ?: throw RuntimeException("सीन ${i + 1} के लिए कोई वीडियो क्लिप नहीं मिली")
        return SceneAsset(audio, audioMs, clip, clipMs)
    }

    /** पहले सीन के शब्द, फिर पहला शब्द, फिर सामान्य शब्द आज़माता है */
    private fun findClip(keywords: String, pexels: Pexels, portrait: Boolean): Pair<File, Long>? {
        val tries = listOf(keywords, keywords.trim().split(" ").first(), "nature landscape", "city skyline")
        for (q in tries) {
            val f = try {
                pexels.find(q, portrait)
            } catch (e: Exception) {
                val m = e.message.orEmpty()
                if (m.startsWith("HTTP 401") || m.startsWith("HTTP 403")) {
                    throw RuntimeException("Pexels की key सही नहीं है ($m)")
                }
                null
            } ?: continue
            val ms = MediaUtil.durationMs(f)
            if (ms >= 2000) return f to ms
        }
        return null
    }
}
