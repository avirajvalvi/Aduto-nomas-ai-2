package com.example.autovideo

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

interface Voice {
    fun speak(text: String, out: File)
    fun close() {}
}

/** ElevenLabs की आवाज़ (पैसे लगते हैं) -> mp3 */
class ElevenVoice(private val key: String, private val voiceId: String) : Voice {
    override fun speak(text: String, out: File) {
        val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
        Http.download(
            Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
                .header("xi-api-key", key)
                .post(body.toString().toRequestBody(Http.jsonType))
                .build(),
            out
        )
    }
}

/** फ़ोन की अपनी TTS आवाज़ (मुफ़्त) -> wav। इसे मेन थ्रेड पर बनाएँ। */
class PhoneVoice(context: Context, private val localeTag: String) : Voice {
    private val ready = CountDownLatch(1)
    private val ok = AtomicBoolean(false)
    private var langChecked = false
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        ok.set(status == TextToSpeech.SUCCESS)
        ready.countDown()
    }

    private fun engine(): TextToSpeech {
        if (!ready.await(20, TimeUnit.SECONDS) || !ok.get()) {
            throw RuntimeException("फ़ोन की TTS आवाज़ चालू नहीं हो पाई")
        }
        if (!langChecked) {
            val r = tts.setLanguage(Locale.forLanguageTag(localeTag))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                throw RuntimeException("फ़ोन में $localeTag आवाज़ इंस्टॉल नहीं है (Settings में Text-to-speech देखें)")
            }
            langChecked = true
        }
        return tts
    }

    override fun speak(text: String, out: File) {
        val t = engine()
        val done = CountDownLatch(1)
        val failed = AtomicBoolean(false)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                done.countDown()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                failed.set(true)
                done.countDown()
            }
        })
        val id = "u" + System.nanoTime()
        if (t.synthesizeToFile(text, null, out, id) != TextToSpeech.SUCCESS) {
            throw RuntimeException("आवाज़ बनाना शुरू नहीं हो पाया")
        }
        if (!done.await(120, TimeUnit.SECONDS) || failed.get()) {
            throw RuntimeException("आवाज़ बनाने में फेल")
        }
    }

    override fun close() {
        tts.shutdown()
    }
}
