package com.example.autovideo

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class Post(val title: String, val text: String, val comments: List<String>)
data class ScriptResult(val title: String, val description: String, val script: String)

/** पूरी पाइपलाइन: Reddit -> Gemini -> ElevenLabs -> HeyGen -> YouTube */
class Pipeline(
    private val s: Map<String, String>,
    private val cacheDir: File,
    private val log: (String) -> Unit
) {
    private val ua = "android:com.example.autovideo:v1.0 (personal use)"
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .build()

    private fun v(key: String): String = s[key].orEmpty()

    private fun callString(req: Request): String =
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: ${body.take(300)}")
            body
        }

    private fun downloadTo(req: Request, file: File) {
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: ${r.body?.string()?.take(300)}")
            r.body!!.byteStream().use { input ->
                file.outputStream().use { out -> input.copyTo(out) }
            }
        }
    }

    // ---------- पूरा क्रम ----------
    fun run(redditUrl: String): String {
        log("1/6 Reddit पोस्ट पढ़ रहा हूँ...")
        val post = fetchReddit(redditUrl)

        log("2/6 Gemini से स्क्रिप्ट लिखवा रहा हूँ...")
        val result = writeScript(post)
        log("शीर्षक: ${result.title}")

        log("3/6 ElevenLabs से आवाज़ बना रहा हूँ...")
        val audio = File(cacheDir, "voice.mp3")
        makeVoice(result.script, audio)

        log("4/6 HeyGen को ऑडियो भेज रहा हूँ...")
        val assetId = heygenUpload(audio)
        val videoId = heygenGenerate(assetId)

        log("5/6 अवतार वीडियो बन रहा है (5-15 मिनट लग सकते हैं, ऐप खुला रखें)...")
        val videoUrl = heygenWait(videoId)
        val video = File(cacheDir, "video.mp4")
        downloadTo(Request.Builder().url(videoUrl).build(), video)

        log("6/6 YouTube पर अपलोड कर रहा हूँ...")
        val id = uploadYoutube(video, result.title.ifBlank { "Reddit कहानी" }, result.description)
        return "https://youtu.be/$id"
    }

    // ---------- 1. Reddit ----------
    private fun fetchReddit(url: String): Post {
        var target = url.trim()
        // Reddit ऐप के शेयर लिंक (/s/xxxx) पहले असली लिंक पर भेजे जाते हैं
        if (Regex("/s/\\w+").containsMatchIn(target)) {
            target = http.newCall(Request.Builder().url(target).header("User-Agent", ua).build())
                .execute().use { it.request.url.toString() }
        }
        val base = target.substringBefore("?").trimEnd('/') + ".json?raw_json=1"
        val candidates = listOf(base, base.replace("://www.reddit.com", "://old.reddit.com"))
        var last: Exception? = null
        for (u in candidates) {
            try {
                val body = callString(Request.Builder().url(u).header("User-Agent", ua).build())
                return parsePost(body)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("Reddit से पोस्ट नहीं मिली")
    }

    private fun parsePost(body: String): Post {
        val arr = JSONArray(body)
        val post = arr.getJSONObject(0).getJSONObject("data")
            .getJSONArray("children").getJSONObject(0).getJSONObject("data")
        val comments = mutableListOf<String>()
        val kids = if (arr.length() > 1)
            arr.getJSONObject(1).getJSONObject("data").getJSONArray("children")
        else JSONArray()
        for (i in 0 until kids.length()) {
            val k = kids.getJSONObject(i)
            if (k.optString("kind") == "t1" && comments.size < 5) {
                comments.add(k.getJSONObject("data").optString("body"))
            }
        }
        return Post(post.optString("title"), post.optString("selftext"), comments)
    }

    // ---------- 2. Gemini ----------
    private fun writeScript(p: Post): ScriptResult {
        val lang = v("language").ifBlank { "हिंदी" }
        val prompt = """
नीचे एक Reddit पोस्ट है। इस पर 60-90 सेकंड का YouTube वीडियो स्क्रिप्ट लिखो।
भाषा: $lang।
नियम: शुरुआत में एक हुक, बीच में मुख्य बातें, अंत में छोटा निष्कर्ष। सिर्फ़ बोले जाने वाले शब्द लिखो,
कोई स्टेज निर्देश या इमोजी नहीं। पोस्ट की बात अपने शब्दों में कहो, कॉपी मत करो।

सिर्फ़ इस JSON फ़ॉर्मेट में जवाब दो:
{"title": "वीडियो का शीर्षक", "description": "YouTube डिस्क्रिप्शन", "script": "बोला जाने वाला पूरा टेक्स्ट"}

पोस्ट का शीर्षक: ${p.title}
पोस्ट का टेक्स्ट: ${p.text.take(4000)}
टॉप कमेंट्स: ${JSONArray(p.comments).toString().take(2000)}
""".trimIndent()

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val model = v("gemini_model").ifBlank { Gemini.DEFAULT_MODEL }
        val resp = callString(
            Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", v("gemini_key"))
                .post(body.toString().toRequestBody(jsonType))
                .build()
        )
        val text = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val clean = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val j = JSONObject(clean)
        return ScriptResult(j.getString("title"), j.optString("description"), j.getString("script"))
    }

    // ---------- 3. ElevenLabs ----------
    private fun makeVoice(script: String, out: File) {
        val body = JSONObject().put("text", script).put("model_id", "eleven_multilingual_v2")
        downloadTo(
            Request.Builder()
                .url("https://api.elevenlabs.io/v1/text-to-speech/${v("el_voice")}")
                .header("xi-api-key", v("el_key"))
                .post(body.toString().toRequestBody(jsonType))
                .build(),
            out
        )
    }

    // ---------- 4. HeyGen ----------
    private fun heygenUpload(audio: File): String {
        val resp = callString(
            Request.Builder()
                .url("https://upload.heygen.com/v1/asset")
                .header("X-Api-Key", v("heygen_key"))
                .post(audio.asRequestBody("audio/mpeg".toMediaType()))
                .build()
        )
        return JSONObject(resp).getJSONObject("data").getString("id")
    }

    private fun heygenGenerate(audioAssetId: String): String {
        val input = JSONObject()
            .put("character", JSONObject()
                .put("type", "avatar")
                .put("avatar_id", v("heygen_avatar"))
                .put("avatar_style", "normal"))
            .put("voice", JSONObject()
                .put("type", "audio")
                .put("audio_asset_id", audioAssetId))
        val body = JSONObject()
            .put("video_inputs", JSONArray().put(input))
            .put("dimension", JSONObject().put("width", 1280).put("height", 720))
        val resp = callString(
            Request.Builder()
                .url("https://api.heygen.com/v2/video/generate")
                .header("X-Api-Key", v("heygen_key"))
                .post(body.toString().toRequestBody(jsonType))
                .build()
        )
        return JSONObject(resp).getJSONObject("data").getString("video_id")
    }

    private fun heygenWait(videoId: String): String {
        repeat(60) { // 60 x 30 सेकंड = अधिकतम 30 मिनट
            val resp = callString(
                Request.Builder()
                    .url("https://api.heygen.com/v1/video_status.get?video_id=$videoId")
                    .header("X-Api-Key", v("heygen_key"))
                    .build()
            )
            val data = JSONObject(resp).getJSONObject("data")
            when (data.optString("status")) {
                "completed" -> return data.getString("video_url")
                "failed" -> throw RuntimeException("HeyGen फेल: ${data.opt("error")}")
            }
            Thread.sleep(30_000)
        }
        throw RuntimeException("HeyGen वीडियो समय पर तैयार नहीं हुआ")
    }

    // ---------- 5. YouTube ----------
    private fun accessToken(): String {
        val form = FormBody.Builder()
            .add("client_id", v("yt_client_id"))
            .add("client_secret", v("yt_client_secret"))
            .add("refresh_token", v("yt_refresh"))
            .add("grant_type", "refresh_token")
            .build()
        val resp = callString(Request.Builder().url("https://oauth2.googleapis.com/token").post(form).build())
        return JSONObject(resp).getString("access_token")
    }

    private fun uploadYoutube(file: File, title: String, description: String): String {
        val token = accessToken()
        val meta = JSONObject()
            .put("snippet", JSONObject()
                .put("title", title.take(100))
                .put("description", description)
                .put("categoryId", "22"))
            .put("status", JSONObject()
                .put("privacyStatus", v("yt_privacy").ifBlank { "private" }))

        val init = Request.Builder()
            .url("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
            .header("Authorization", "Bearer $token")
            .header("X-Upload-Content-Type", "video/mp4")
            .header("X-Upload-Content-Length", file.length().toString())
            .post(meta.toString().toRequestBody(jsonType))
            .build()

        val location = http.newCall(init).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("YouTube HTTP ${r.code}: ${r.body?.string()?.take(300)}")
            r.header("Location") ?: throw RuntimeException("अपलोड URL नहीं मिला")
        }

        val put = Request.Builder()
            .url(location)
            .header("Authorization", "Bearer $token")
            .put(file.asRequestBody("video/mp4".toMediaType()))
            .build()
        return JSONObject(callString(put)).getString("id")
    }
}
