package com.example.autovideo

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Field(val key: String, val label: String, val secret: Boolean, val default: String)

val FIELDS = listOf(
    Field("gemini_key", "Gemini API Key", true, ""),
    Field("gemini_model", "Gemini मॉडल", false, Gemini.DEFAULT_MODEL),
    Field("pexels_key", "Pexels API Key (मुफ़्त स्टॉक वीडियो)", true, ""),
    Field("voice_engine", "आवाज़: phone (मुफ़्त) या elevenlabs", false, "phone"),
    Field("voice_locale", "फ़ोन आवाज़ की भाषा (hi-IN / en-IN)", false, "hi-IN"),
    Field("el_key", "ElevenLabs API Key", true, ""),
    Field("el_voice", "ElevenLabs Voice ID", false, ""),
    Field("heygen_key", "HeyGen API Key", true, ""),
    Field("heygen_avatar", "HeyGen Avatar ID", false, ""),
    Field("yt_client_id", "YouTube Client ID", false, ""),
    Field("yt_client_secret", "YouTube Client Secret", true, ""),
    Field("yt_refresh", "YouTube Refresh Token", true, ""),
    Field("yt_privacy", "YouTube प्राइवेसी (private / unlisted / public)", false, "private"),
    Field("language", "स्क्रिप्ट की भाषा", false, "हिंदी")
)

/** Reddit मोड की ज़रूरी की */
val REQUIRED = listOf(
    "gemini_key", "el_key", "el_voice", "heygen_key", "heygen_avatar",
    "yt_client_id", "yt_client_secret", "yt_refresh"
)

fun requiredForPrompt(s: Map<String, String>): List<String> {
    val base = listOf("gemini_key", "pexels_key")
    val eleven = if (s["voice_engine"].equals("elevenlabs", ignoreCase = true)) {
        listOf("el_key", "el_voice")
    } else {
        emptyList()
    }
    return base + eleven
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private var job: Job? = null

    val logs = mutableStateListOf<String>()
    val outputs = mutableStateListOf<Uri>()
    var running by mutableStateOf(false)
    var status by mutableStateOf("")
    var resultLink by mutableStateOf("")

    fun load(): Map<String, String> {
        val m = FIELDS.associate { it.key to (prefs.getString(it.key, it.default) ?: it.default) }.toMutableMap()
        // पुराना मॉडल हट रहा है, इसलिए नए डिफ़ॉल्ट पर ले आओ
        val model = m["gemini_model"].orEmpty()
        if (model.isBlank() || model == "gemini-2.5-flash") m["gemini_model"] = Gemini.DEFAULT_MODEL
        return m
    }

    fun save(values: Map<String, String>) {
        val e = prefs.edit()
        values.forEach { (k, v) -> e.putString(k, v.trim()) }
        e.apply()
    }

    fun stop() {
        job?.cancel()
    }

    private fun reset() {
        logs.clear()
        outputs.clear()
        resultLink = ""
        status = ""
    }

    // ---------- Reddit -> HeyGen -> YouTube (पहले वाला) ----------
    fun start(url: String) {
        if (running) return
        val s = load()
        val missing = REQUIRED.filter { s[it].isNullOrBlank() }
        reset()
        if (missing.isNotEmpty()) {
            logs.add("पहले सेटिंग्स में सभी API की भरें।")
            return
        }
        running = true
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val pipeline = Pipeline(s, getApplication<Application>().cacheDir) { logs.add(it) }
                val link = pipeline.run(url)
                logs.add("तैयार! वीडियो: $link")
                resultLink = link
            } catch (e: Exception) {
                logs.add("फेल हुआ: ${e.message}")
            } finally {
                running = false
            }
        }
    }

    // ---------- प्रॉम्प्ट से वीडियो ----------
    fun startPrompt(prompt: String, minutes: Int, portrait: Boolean) {
        if (running) return
        val s = load()
        val missing = requiredForPrompt(s).filter { s[it].isNullOrBlank() }
        reset()
        if (missing.isNotEmpty()) {
            logs.add("पहले सेटिंग्स में ये भरें: ${missing.joinToString()}")
            return
        }
        running = true
        job = viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val file = PromptPipeline(app, s, { logs.add(it) }, { status = it }).run(prompt, minutes, portrait)
                val uri = withContext(Dispatchers.IO) {
                    MediaUtil.saveToGallery(app, file, "AutoVideo_${System.currentTimeMillis()}.mp4")
                }
                if (uri != null) outputs.add(uri)
                logs.add("तैयार! वीडियो गैलरी में Movies/AutoVideo के अंदर सेव हो गया।")
            } catch (e: CancellationException) {
                logs.add("रोक दिया गया।")
                throw e
            } catch (e: Exception) {
                logs.add("फेल हुआ: ${e.message}")
            } finally {
                running = false
                status = ""
            }
        }
    }

    // ---------- अपने वीडियो से वायरल क्लिप्स ----------
    fun startClips(source: Uri, count: Int, portrait: Boolean, note: String) {
        if (running) return
        val s = load()
        reset()
        if (s["gemini_key"].isNullOrBlank()) {
            logs.add("पहले सेटिंग्स में Gemini API Key भरें।")
            return
        }
        running = true
        job = viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val shorts = ClipsPipeline(app, s, { logs.add(it) }, { status = it }).run(source, count, portrait, note)
                for ((i, pair) in shorts.withIndex()) {
                    val uri = withContext(Dispatchers.IO) {
                        MediaUtil.saveToGallery(app, pair.first, "Short_${System.currentTimeMillis()}_${i + 1}.mp4")
                    }
                    if (uri != null) outputs.add(uri)
                }
                logs.add("तैयार! ${shorts.size} शॉर्ट्स गैलरी में Movies/AutoVideo के अंदर हैं।")
            } catch (e: CancellationException) {
                logs.add("रोक दिया गया।")
                throw e
            } catch (e: Exception) {
                logs.add("फेल हुआ: ${e.message}")
            } finally {
                running = false
                status = ""
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // वीडियो बनते समय स्क्रीन चालू रहे
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val sharedText = intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val sharedUrl = Regex("https?://\\S+").find(sharedText)?.value.orEmpty()

        setContent { App(sharedUrl) }
    }
}

fun openVideo(ctx: Context, uri: Uri) {
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "video/mp4")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(i)
    } catch (e: Exception) {
        // कोई वीडियो ऐप नहीं मिला
    }
}

@Composable
fun App(initialUrl: String, vm: AppViewModel = viewModel()) {
    var settings by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(if (initialUrl.isNotEmpty()) 0 else 1) }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth()) {
                    Text("ऑटो वीडियो", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { settings = !settings }) {
                        Text(if (settings) "वापस" else "सेटिंग्स")
                    }
                }
                if (settings) {
                    SettingsScreen(vm) { settings = false }
                } else {
                    ModeBar(tab) { tab = it }
                    when (tab) {
                        0 -> Home(vm, initialUrl)
                        1 -> PromptScreen(vm)
                        else -> ClipsScreen(vm)
                    }
                }
            }
        }
    }
}

@Composable
fun ModeBar(selected: Int, onSelect: (Int) -> Unit) {
    val names = listOf("Reddit", "प्रॉम्प्ट", "क्लिप्स")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n ->
            if (i == selected) {
                Button(onClick = { onSelect(i) }, modifier = Modifier.weight(1f)) { Text(n) }
            } else {
                OutlinedButton(onClick = { onSelect(i) }, modifier = Modifier.weight(1f)) { Text(n) }
            }
        }
    }
}

@Composable
fun OrientationPicker(portrait: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!portrait) {
            Button(onClick = { onChange(false) }, modifier = Modifier.weight(1f)) { Text("आड़ा 16:9") }
            OutlinedButton(onClick = { onChange(true) }, modifier = Modifier.weight(1f)) { Text("वर्टिकल 9:16") }
        } else {
            OutlinedButton(onClick = { onChange(false) }, modifier = Modifier.weight(1f)) { Text("आड़ा 16:9") }
            Button(onClick = { onChange(true) }, modifier = Modifier.weight(1f)) { Text("वर्टिकल 9:16") }
        }
    }
}

/** प्रगति, रोकें बटन, तैयार वीडियो और लॉग: दोनों नए मोड में एक जैसे */
fun LazyListScope.results(vm: AppViewModel, ctx: Context) {
    if (vm.running) {
        item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        item { Text(vm.status) }
        item {
            OutlinedButton(onClick = { vm.stop() }, modifier = Modifier.fillMaxWidth()) { Text("रोकें") }
        }
    }
    items(vm.outputs) { u ->
        Button(onClick = { openVideo(ctx, u) }, modifier = Modifier.fillMaxWidth()) { Text("वीडियो खोलें") }
    }
    items(vm.logs) { Text(it, style = MaterialTheme.typography.bodyMedium) }
}

@Composable
fun Home(vm: AppViewModel, initialUrl: String) {
    var url by remember { mutableStateOf(initialUrl) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Reddit लिंक पेस्ट करें") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { vm.start(url.trim()) },
            enabled = !vm.running && url.contains("reddit.com"),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (vm.running) "बन रहा है..." else "वीडियो बनाओ")
        }
        if (vm.running) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.resultLink.isNotEmpty()) {
            Button(
                onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(vm.resultLink))) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("YouTube पर खोलें") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.logs) { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
fun PromptScreen(vm: AppViewModel) {
    var prompt by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("5") }
    var portrait by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("वीडियो किस बारे में हो?") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = minutes,
                onValueChange = { minutes = it.filter { c -> c.isDigit() }.take(2) },
                label = { Text("लंबाई (मिनट, 1 से 30)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { OrientationPicker(portrait) { portrait = it } }
        item {
            Button(
                onClick = { vm.startPrompt(prompt.trim(), (minutes.toIntOrNull() ?: 5).coerceIn(1, 30), portrait) },
                enabled = !vm.running && prompt.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (vm.running) "बन रहा है..." else "वीडियो बनाओ")
            }
        }
        results(vm, ctx)
    }
}

@Composable
fun ClipsScreen(vm: AppViewModel) {
    var picked by remember { mutableStateOf<Uri?>(null) }
    var count by remember { mutableStateOf("3") }
    var note by remember { mutableStateOf("") }
    var portrait by remember { mutableStateOf(true) }
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) picked = uri
    }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("सिर्फ़ अपने वीडियो (या जिनकी अनुमति हो) चुनें। दूसरों के YouTube वीडियो काटकर डालना कॉपीराइट की दिक्कत बन सकता है।")
        }
        item {
            OutlinedButton(onClick = { launcher.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (picked == null) "वीडियो चुनें" else "वीडियो चुन लिया (बदलने के लिए दबाएँ)")
            }
        }
        item {
            OutlinedTextField(
                value = count,
                onValueChange = { count = it.filter { c -> c.isDigit() }.take(1) },
                label = { Text("कितने शॉर्ट्स (1 से 8)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("कैसे हिस्से चाहिए? (वैकल्पिक)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { OrientationPicker(portrait) { portrait = it } }
        item {
            Button(
                onClick = {
                    val src = picked
                    if (src != null) vm.startClips(src, (count.toIntOrNull() ?: 3).coerceIn(1, 8), portrait, note.trim())
                },
                enabled = !vm.running && picked != null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (vm.running) "बन रहा है..." else "शॉर्ट्स बनाओ")
            }
        }
        results(vm, ctx)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, onDone: () -> Unit) {
    val values = remember { mutableStateMapOf<String, String>().apply { putAll(vm.load()) } }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FIELDS.forEach { f ->
            OutlinedTextField(
                value = values[f.key] ?: "",
                onValueChange = { values[f.key] = it },
                label = { Text(f.label) },
                singleLine = true,
                visualTransformation = if (f.secret) PasswordVisualTransformation() else VisualTransformation.None,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Button(onClick = { vm.save(values); onDone() }, modifier = Modifier.fillMaxWidth()) {
            Text("सेव करें")
        }
    }
}
