package com.example.autovideo

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Media3 Transformer से क्लिप काटना, जोड़ना, आड़ा/वर्टिकल करना और MP4 बनाना */
object VideoComposer {
    fun sizeFor(portrait: Boolean): Pair<Int, Int> = if (portrait) 720 to 1280 else 1280 to 720

    private fun fitEffects(portrait: Boolean): Effects {
        val (w, h) = sizeFor(portrait)
        val presentation = Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        return Effects(emptyList<AudioProcessor>(), listOf<Effect>(presentation))
    }

    private fun clipItem(uri: Uri, startMs: Long, endMs: Long): MediaItem {
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        return MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
    }

    /** प्रॉम्प्ट वाला वीडियो: हर सीन की क्लिप (बिना आवाज़) + अलग ट्रैक पर नैरेशन */
    fun buildComposition(scenes: List<SceneAsset>, portrait: Boolean): Composition {
        val effects = fitEffects(portrait)
        val video = ArrayList<EditedMediaItem>()
        val audio = ArrayList<EditedMediaItem>()
        for (s in scenes) {
            for (sl in Slicer.slicesFor(s.audioMs, s.clipMs)) {
                video.add(
                    EditedMediaItem.Builder(clipItem(Uri.fromFile(s.clip), sl.startMs, sl.endMs))
                        .setRemoveAudio(true)
                        .setEffects(effects)
                        .build()
                )
            }
            audio.add(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(s.audio))).build())
        }
        return Composition.Builder(EditedMediaItemSequence(video), EditedMediaItemSequence(audio)).build()
    }

    /** क्लिप्स वाला शॉर्ट: एक वीडियो का [startMs, endMs] हिस्सा, आवाज़ सहित */
    fun singleClip(uri: Uri, startMs: Long, endMs: Long, portrait: Boolean): Composition {
        val edited = EditedMediaItem.Builder(clipItem(uri, startMs, endMs))
            .setEffects(fitEffects(portrait))
            .build()
        return Composition.Builder(EditedMediaItemSequence(listOf(edited))).build()
    }

    /** Transformer मेन थ्रेड पर ही चलना चाहिए */
    suspend fun export(context: Context, composition: Composition, out: File, onProgress: (Int) -> Unit) {
        if (out.exists()) out.delete()
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                val transformer = Transformer.Builder(context)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                transformer.start(composition, out.absolutePath)

                val handler = Handler(Looper.getMainLooper())
                val holder = ProgressHolder()
                val poll = object : Runnable {
                    override fun run() {
                        if (!cont.isActive) return
                        if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                            onProgress(holder.progress)
                        }
                        handler.postDelayed(this, 2000)
                    }
                }
                handler.postDelayed(poll, 2000)
                cont.invokeOnCancellation {
                    handler.removeCallbacks(poll)
                    handler.post { transformer.cancel() }
                }
            }
        }
    }
}
