package com.example.autovideo

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

/** नए मॉड्यूल्स का साझा नेटवर्क क्लाइंट */
object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS)
        .writeTimeout(600, TimeUnit.SECONDS)
        .build()

    val jsonType = "application/json; charset=utf-8".toMediaType()

    fun string(req: Request): String =
        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: ${body.take(300)}")
            body
        }

    fun download(req: Request, file: File) {
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("HTTP ${r.code}: ${r.body?.string()?.take(300)}")
            val body = r.body ?: throw RuntimeException("खाली जवाब मिला")
            body.byteStream().use { input ->
                file.outputStream().use { out -> input.copyTo(out) }
            }
        }
    }
}
