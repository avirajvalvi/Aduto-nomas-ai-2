package com.example.autovideo

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object MediaUtil {
    fun durationMs(file: File): Long = duration { it.setDataSource(file.absolutePath) }

    fun durationMs(ctx: Context, uri: Uri): Long = duration { it.setDataSource(ctx, uri) }

    private fun duration(setup: (MediaMetadataRetriever) -> Unit): Long {
        val r = MediaMetadataRetriever()
        try {
            setup(r)
            return r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            return 0L
        } finally {
            r.release()
        }
    }

    /** वीडियो को गैलरी (Movies/AutoVideo) में रखता है और कैश की फ़ाइल हटा देता है */
    fun saveToGallery(ctx: Context, file: File, name: String): Uri? {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AutoVideo")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
        file.delete()
        return uri
    }
}
