package com.example.autovideo

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import okio.source
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

data class ClipSpec(val startMs: Long, val endMs: Long, val title: String)

/** Gemini के जवाब से क्लिप के समय निकालना (बिना Android के, टेस्ट हो सकता है) */
object ClipParser {
    fun toMs(v: Any?): Long? = when (v) {
        is Number -> (v.toDouble() * 1000).toLong()
        is String -> {
            val t = v.trim()
            if (t.contains(":")) {
                var sec = 0.0
                for (p in t.split(":")) {
                    val x = p.trim().toDoubleOrNull() ?: return null
                    sec = sec * 60 + x
                }
                (sec * 1000).toLong()
            } else {
                t.toDoubleOrNull()?.let { (it * 1000).toLong() }
            }
        }
        else -> null
    }

    fun parse(json: String, totalMs: Long, maxCount: Int): List<ClipSpec> {
        val root = if (json.trimStart().startsWith("[")) {
            JSONObject().put("clips", JSONArray(json))
        } else {
            JSONObject(json)
        }
        val arr = root.optJSONArray("clips") ?: throw RuntimeException("जवाब में clips नहीं मिले")
        val out = ArrayList<ClipSpec>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val a = toMs(o.opt("start")) ?: continue
            val b = toMs(o.opt("end")) ?: continue
            val start = a.coerceIn(0L, totalMs)
            var end = b.coerceIn(0L, totalMs)
            if (end - start > 90_000L) end = start + 90_000L
            if (end - start < 5_000L) continue
            out.add(ClipSpec(start, end, o.optString("title").ifBlank { "Clip ${out.size + 1}" }))
            if (out.size >= maxCount) break
        }
        if (out.isEmpty()) throw RuntimeException("कोई सही हिस्सा नहीं मिला")
        return out
    }
}

private class StreamBody(
    private val ctx: Context,
    private val uri: Uri,
    private val type: MediaType?,
    private val len: Long
) : RequestBody() {
    override fun contentType(): MediaType? = type
    override fun contentLength(): Long = len
    override fun writeTo(sink: BufferedSink) {
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("फ़ाइल खुल नहीं रही")
        input.use { sink.writeAll(it.source()) }
    }
}

/**
 * अपना वीडियो चुनें -> Gemini को भेजें (Files API) -> सबसे दमदार हिस्से -> Media3 से शॉर्ट्स
 */
class ClipsPipeline(
    private val ctx: Context,
    private val s: Map<String, String>,
    private val log: (String) -> Unit,
    private val status: (String) -> Unit
) {
    private fun v(k: String): String = s[k].orEmpty()

    suspend fun run(uri: Uri, count: Int, portrait: Boolean, note: String): List<Pair<File, String>> {
        val totalMs = MediaUtil.durationMs(ctx, uri)
        if (totalMs < 20_000L) throw RuntimeException("वीडियो बहुत छोटा है या पढ़ा नहीं जा सका")
        val mime = ctx.contentResolver.getType(uri) ?: "video/mp4"

        val specs = withContext(Dispatchers.IO) {
            status("वीडियो Gemini को भेज रहा हूँ...")
            log("वीडियो Gemini को भेज रहा हूँ (बड़ी फ़ाइल में समय लगेगा)...")
            val fileUri = uploadToGemini(uri, mime)
            status("Gemini सबसे अच्छे हिस्से ढूँढ रहा है...")
            log("Gemini सबसे अच्छे हिस्से ढूँढ रहा है...")
            val gem = Gemini(v("gemini_key"), v("gemini_model"))
            ClipParser.parse(gem.json(clipsPrompt(count, totalMs, note), fileUri, mime), totalMs, count)
        }
        log("${specs.size} हिस्से मिले।")

        val results = ArrayList<Pair<File, String>>()
        for ((i, spec) in specs.withIndex()) {
            currentCoroutineContext().ensureActive()
            val label = "शॉर्ट ${i + 1}/${specs.size}"
            status("$label बन रहा है...")
            val out = File(ctx.cacheDir, "short_${System.currentTimeMillis()}_$i.mp4")
            val composition = VideoComposer.singleClip(uri, spec.startMs, spec.endMs, portrait)
            VideoComposer.export(ctx, composition, out) { p -> status("$label: $p%") }
            log("$label तैयार: ${spec.title}")
            results.add(out to spec.title)
        }
        return results
    }

    private fun clipsPrompt(count: Int, totalMs: Long, note: String): String = """
इस वीडियो को ध्यान से देखो और सुनो। इसमें से $count सबसे वायरल और दमदार हिस्से चुनो जो अकेले शॉर्ट्स/रील्स के रूप में चल सकें।
नियम: हर हिस्सा 20 से 60 सेकंड का हो, शुरुआत में ही हुक हो, और बात बीच में न कटे। हिस्से आपस में न टकराएँ।
वीडियो की कुल लंबाई ${totalMs / 1000} सेकंड है, समय इससे बाहर न जाए।
${if (note.isBlank()) "" else "ख़ास निर्देश: $note"}
सिर्फ़ इस JSON में जवाब दो (start और end सेकंड में, संख्या के रूप में):
{"clips": [{"start": 12.0, "end": 48.0, "title": "छोटा आकर्षक शीर्षक"}]}
""".trimIndent()

    /** Gemini Files API: resumable अपलोड, फिर ACTIVE होने तक इंतज़ार */
    private fun uploadToGemini(uri: Uri, mime: String): String {
        val key = v("gemini_key")
        val length = ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (length <= 0L) throw RuntimeException("फ़ाइल का साइज़ पता नहीं चला")

        val start = Request.Builder()
            .url("https://generativelanguage.googleapis.com/upload/v1beta/files")
            .header("x-goog-api-key", key)
            .header("X-Goog-Upload-Protocol", "resumable")
            .header("X-Goog-Upload-Command", "start")
            .header("X-Goog-Upload-Header-Content-Length", length.toString())
            .header("X-Goog-Upload-Header-Content-Type", mime)
            .post("""{"file": {"display_name": "clips_source"}}""".toRequestBody(Http.jsonType))
            .build()
        val uploadUrl = Http.client.newCall(start).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("Gemini अपलोड शुरू नहीं हुआ: HTTP ${r.code}")
            r.header("x-goog-upload-url") ?: throw RuntimeException("अपलोड URL नहीं मिला")
        }

        val up = Request.Builder()
            .url(uploadUrl)
            .header("X-Goog-Upload-Offset", "0")
            .header("X-Goog-Upload-Command", "upload, finalize")
            .post(StreamBody(ctx, uri, mime.toMediaType(), length))
            .build()
        val info = JSONObject(Http.string(up)).getJSONObject("file")
        val name = info.getString("name")
        var fileUri = info.getString("uri")
        var state = info.optString("state")

        var waited = 0
        while (state != "ACTIVE") {
            if (state == "FAILED") throw RuntimeException("Gemini यह वीडियो प्रोसेस नहीं कर सका")
            if (waited > 900) throw RuntimeException("Gemini की प्रोसेसिंग में बहुत समय लगा")
            Thread.sleep(5000)
            waited += 5
            val g = JSONObject(
                Http.string(
                    Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/$name")
                        .header("x-goog-api-key", key)
                        .build()
                )
            )
            state = g.optString("state")
            fileUri = g.optString("uri", fileUri)
        }
        return fileUri
    }
}
