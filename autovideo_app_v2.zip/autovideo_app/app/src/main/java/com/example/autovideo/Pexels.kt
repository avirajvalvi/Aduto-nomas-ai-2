package com.example.autovideo

import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import kotlin.math.abs

/** Pexels से मुफ़्त स्टॉक वीडियो क्लिप ढूँढकर डाउनलोड करता है */
class Pexels(private val key: String, private val dir: File) {
    private val used = HashSet<String>()

    fun find(keywords: String, portrait: Boolean): File? {
        val q = URLEncoder.encode(keywords, "UTF-8")
        val orient = if (portrait) "portrait" else "landscape"
        val body = Http.string(
            Request.Builder()
                .url("https://api.pexels.com/videos/search?query=$q&orientation=$orient&per_page=10&size=medium")
                .header("Authorization", key)
                .build()
        )
        val link = pickLink(body, used) ?: return null
        used.add(link)
        val f = File(dir, "px_" + (link.hashCode().toLong() and 0xffffffffL) + ".mp4")
        if (!f.exists() || f.length() == 0L) {
            Http.download(Request.Builder().url(link).build(), f)
        }
        return f
    }

    companion object {
        /** पहला ऐसा वीडियो जो अभी तक इस्तेमाल नहीं हुआ; सब इस्तेमाल हो चुके हों तो पहला */
        fun pickLink(body: String, used: Set<String>): String? {
            val videos = JSONObject(body).optJSONArray("videos") ?: return null
            var fallback: String? = null
            for (i in 0 until videos.length()) {
                val link = bestFile(videos.getJSONObject(i)) ?: continue
                if (link !in used) return link
                if (fallback == null) fallback = link
            }
            return fallback
        }

        /** 720 के आसपास की mp4 फ़ाइल चुनता है (4K जैसी भारी फ़ाइलें नहीं) */
        fun bestFile(video: JSONObject): String? {
            val files = video.optJSONArray("video_files") ?: return null
            var best: String? = null
            var bestScore = Long.MAX_VALUE
            for (i in 0 until files.length()) {
                val f = files.getJSONObject(i)
                if (f.optString("file_type") != "video/mp4") continue
                val link = f.optString("link")
                if (link.isBlank()) continue
                val side = minOf(f.optInt("width"), f.optInt("height"))
                if (side < 540) continue
                val score = abs(side - 720).toLong()
                if (score < bestScore) {
                    bestScore = score
                    best = link
                }
            }
            return best
        }
    }
}
