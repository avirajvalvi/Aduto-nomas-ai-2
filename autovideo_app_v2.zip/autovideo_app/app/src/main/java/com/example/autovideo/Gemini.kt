package com.example.autovideo

import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Gemini generateContent: सिर्फ़ JSON जवाब (वैकल्पिक रूप से अपलोड की हुई फ़ाइल के साथ) */
class Gemini(private val key: String, model: String) {
    private val model = model.ifBlank { DEFAULT_MODEL }

    fun json(prompt: String, fileUri: String? = null, mime: String? = null): String {
        val parts = JSONArray()
        if (fileUri != null) {
            parts.put(
                JSONObject().put(
                    "file_data",
                    JSONObject().put("mime_type", mime ?: "video/mp4").put("file_uri", fileUri)
                )
            )
        }
        parts.put(JSONObject().put("text", prompt))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        var last: RuntimeException? = null
        repeat(3) { attempt ->
            try {
                val resp = Http.string(
                    Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                        .header("x-goog-api-key", key)
                        .post(body.toString().toRequestBody(Http.jsonType))
                        .build()
                )
                return cleanJson(extractText(resp))
            } catch (e: RuntimeException) {
                last = e
                val m = e.message.orEmpty()
                val retryable = m.startsWith("HTTP 429") || m.startsWith("HTTP 5")
                if (!retryable) throw e
                Thread.sleep(3000L * (attempt + 1))
            }
        }
        throw last ?: RuntimeException("Gemini ने जवाब नहीं दिया")
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"

        fun extractText(resp: String): String {
            val cands = JSONObject(resp).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) {
                throw RuntimeException("Gemini से खाली जवाब: ${resp.take(200)}")
            }
            val parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            return sb.toString()
        }

        /** ```json ... ``` जैसे घेरे हटाकर सिर्फ़ JSON हिस्सा लौटाता है */
        fun cleanJson(text: String): String {
            val t = text.trim()
            val start = t.indexOfFirst { it == '{' || it == '[' }
            val end = t.indexOfLast { it == '}' || it == ']' }
            return if (start >= 0 && end > start) t.substring(start, end + 1) else t
        }
    }
}
