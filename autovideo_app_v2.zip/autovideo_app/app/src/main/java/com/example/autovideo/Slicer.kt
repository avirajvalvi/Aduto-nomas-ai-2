package com.example.autovideo

import java.io.File

/** एक सीन: आवाज़ की फ़ाइल + उसके नीचे चलने वाली वीडियो क्लिप */
data class SceneAsset(val audio: File, val audioMs: Long, val clip: File, val clipMs: Long)

data class Slice(val startMs: Long, val endMs: Long)

object Slicer {
    const val MIN_SLICE_MS = 400L

    /**
     * आवाज़ totalMs की है, क्लिप clipMs की। क्लिप छोटी हो तो उसे दोहराकर
     * ठीक totalMs भरने वाले टुकड़ों की सूची देता है (कुल योग हमेशा बराबर रहता है)।
     */
    fun slicesFor(totalMs: Long, clipMs: Long): List<Slice> {
        val usable = maxOf(clipMs - 100, MIN_SLICE_MS * 2)
        val out = ArrayList<Slice>()
        var left = maxOf(totalMs, MIN_SLICE_MS)
        while (left > 0) {
            val take = minOf(left, usable)
            if (take < MIN_SLICE_MS && out.isNotEmpty()) {
                val prev = out.removeAt(out.lastIndex)
                val shift = MIN_SLICE_MS - take
                out.add(Slice(0, prev.endMs - shift))
                out.add(Slice(0, MIN_SLICE_MS))
            } else {
                out.add(Slice(0, take))
            }
            left -= take
        }
        return out
    }
}
