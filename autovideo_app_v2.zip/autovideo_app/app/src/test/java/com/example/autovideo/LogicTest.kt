package com.example.autovideo

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class LogicTest {

    // ---- Slicer: क्लिप दोहराकर ठीक आवाज़ की लंबाई भरना ----
    @Test
    fun slicesAlwaysSumToTotal() {
        for (total in listOf(1000L, 3000L, 9810L, 12345L, 20000L, 45678L)) {
            for (clip in listOf(2000L, 5000L, 9000L, 15000L)) {
                val slices = Slicer.slicesFor(total, clip)
                assertEquals("total=$total clip=$clip", total, slices.sumOf { it.endMs - it.startMs })
                assertTrue(slices.all { it.endMs - it.startMs >= Slicer.MIN_SLICE_MS })
                assertTrue(slices.all { it.endMs <= clip })
            }
        }
    }

    // ---- Planner ----
    @Test
    fun chunkMath() {
        assertEquals(1, Planner.chunkCount(1))
        assertEquals(1, Planner.chunkCount(3))
        assertEquals(2, Planner.chunkCount(4))
        assertEquals(10, Planner.chunkCount(30))
        assertEquals(390, Planner.wordsPerChunk(30, 10))
    }

    @Test
    fun parseScenesFromObjectAndArray() {
        val obj = """{"scenes":[{"narration":"नमस्ते दोस्तों","keywords":"city night"},{"narration":"  ","keywords":"x"}]}"""
        val a = Planner.parseScenes(obj)
        assertEquals(1, a.size)
        assertEquals("city night", a[0].keywords)

        val arr = """[{"narration":"एक"},{"narration":"दो","keywords":"sea"}]"""
        val b = Planner.parseScenes(arr)
        assertEquals(2, b.size)
        assertEquals("abstract background", b[0].keywords)
    }

    @Test
    fun parseScenesRejectsEmpty() {
        try {
            Planner.parseScenes("""{"scenes":[]}""")
            fail("खाली scenes पर एरर आना चाहिए था")
        } catch (e: RuntimeException) {
            // ठीक
        }
    }

    @Test
    fun parseOutlinePadsMissingParts() {
        val o = Planner.parseOutline("""{"title":"T","description":"D","parts":["a"]}""", 3)
        assertEquals("T", o.title)
        assertEquals(3, o.parts.size)
    }

    // ---- Gemini जवाब ----
    @Test
    fun cleanJsonStripsFences() {
        assertEquals("""{"a":1}""", Gemini.cleanJson("```json\n{\"a\":1}\n```"))
    }

    @Test
    fun extractTextJoinsParts() {
        val resp = """{"candidates":[{"content":{"parts":[{"text":"{\"a\":"},{"text":"1}"}]}}]}"""
        assertEquals("""{"a":1}""", Gemini.extractText(resp))
    }

    // ---- क्लिप्स ----
    @Test
    fun toMsHandlesNumbersAndClockStrings() {
        assertEquals(12_500L, ClipParser.toMs(12.5))
        assertEquals(83_000L, ClipParser.toMs("01:23"))
        assertEquals(3_723_000L, ClipParser.toMs("1:02:03"))
        assertEquals(7_000L, ClipParser.toMs("7"))
        assertNull(ClipParser.toMs("abc"))
        assertNull(ClipParser.toMs(null))
    }

    @Test
    fun parseClipsClampsAndFilters() {
        val json = """{"clips":[
            {"start":10,"end":40,"title":"पहला"},
            {"start":100,"end":103,"title":"बहुत छोटा"},
            {"start":"01:00","end":"03:30","title":"बहुत लंबा"},
            {"start":170,"end":500,"title":"बाहर तक"}
        ]}"""
        val c = ClipParser.parse(json, 180_000L, 8)
        assertEquals(3, c.size)
        assertEquals(30_000L, c[0].endMs - c[0].startMs)
        assertEquals(90_000L, c[1].endMs - c[1].startMs)   // 90 सेकंड पर कटा
        assertTrue(c[2].endMs <= 180_000L)                  // वीडियो के अंदर ही
    }

    @Test
    fun parseClipsRespectsMaxCount() {
        val json = """{"clips":[{"start":0,"end":30},{"start":40,"end":70},{"start":80,"end":110}]}"""
        assertEquals(2, ClipParser.parse(json, 200_000L, 2).size)
    }

    // ---- Pexels ----
    @Test
    fun pexelsPicksNearest720AndAvoidsUsed() {
        val body = """{"videos":[
          {"video_files":[
            {"file_type":"video/mp4","width":3840,"height":2160,"link":"https://x/4k.mp4"},
            {"file_type":"video/mp4","width":1280,"height":720,"link":"https://x/a720.mp4"},
            {"file_type":"video/mp4","width":640,"height":360,"link":"https://x/small.mp4"}]},
          {"video_files":[
            {"file_type":"video/mp4","width":1920,"height":1080,"link":"https://x/b1080.mp4"}]}
        ]}"""
        assertEquals("https://x/a720.mp4", Pexels.pickLink(body, emptySet()))
        assertEquals("https://x/b1080.mp4", Pexels.pickLink(body, setOf("https://x/a720.mp4")))
        // सब इस्तेमाल हो चुके हों तो भी कुछ तो लौटे
        assertNotNull(Pexels.pickLink(body, setOf("https://x/a720.mp4", "https://x/b1080.mp4")))
        assertNull(Pexels.pickLink("""{"videos":[]}""", emptySet()))
        assertEquals("https://x/a720.mp4", Pexels.bestFile(JSONObject(body).getJSONArray("videos").getJSONObject(0)))
    }
}
