# बिल्ड एरर: कैसे पढ़ें और ठीक करें

## 1. एरर कहाँ दिखेगा

GitHub में रिपो खोलें → **Actions** → लाल ❌ वाला रन खोलें।

- **Summary** में एरर का हिस्सा अपने-आप दिखता है।
- पूरा लॉग देखना हो तो लाल स्टेप **Build Debug APK** खोलें, या नीचे **Artifacts → build-logs** डाउनलोड करें।
- लॉग में `e: ...kt:लाइन` या `What went wrong` ढूँढें। असली एरर वहीं होता है, सबसे आख़िरी लाइनें अक्सर सिर्फ़ नतीजा बताती हैं।

## 2. ठीक करने का तरीका

1. एरर वाली 30-40 लाइनें कॉपी करें, जिनमें `What went wrong` या `e:` शामिल हो।
2. उसमें जिस फ़ाइल का नाम आए, वह फ़ाइल भी साथ भेजें।
3. ठीक की हुई फ़ाइल रिपो में पुश करें। बिल्ड अपने-आप दोबारा चलेगा।

## 3. आम एरर और हल

**वर्कफ़्लो चला ही नहीं, Actions टैब खाली है**
`.github/workflows/` फ़ोल्डर रिपो की सबसे ऊपरी (root) जगह पर होना चाहिए, `autovideo_app/` जैसे सबफ़ोल्डर के अंदर नहीं। फिर Settings → Actions → General में Actions चालू करें।

**एक्शन शुरू होते ही फेल, Node 20 का ज़िक्र**
GitHub ने Node 20 रनटाइम हटाने की तारीख़ 16 सितंबर 2026 रखी थी, इसलिए `@v4` वाले एक्शन फेल हो सकते हैं। इस प्रोजेक्ट में नए वर्शन लगे हैं (checkout@v6, setup-java@v5, setup-gradle@v5, upload-artifact@v6)। भविष्य में ऐसा दिखे तो हर एक्शन का वर्शन नया करें।

**Minimum supported Gradle version / requires Java 17**
Gradle 8.9 और Java 17 ही रखें। AGP 8.5.2 के साथ Gradle 9 नहीं चलता। AGP का वर्शन बदलें तो Gradle का वर्शन भी उसके हिसाब से बदलें।

**`e: ...Unresolved reference` या `Type mismatch`**
यह कोड का एरर है। एरर में लिखी फ़ाइल और लाइन नंबर खोलें, नाम/इम्पोर्ट/टाइप सुधारें।

**Could not resolve ... / Could not GET ...**
अक्सर नेटवर्क की अस्थायी गड़बड़ी होती है। रन खोलकर **Re-run failed jobs** दबाएँ। फिर भी आए तो डिपेंडेंसी का नाम और वर्शन जाँचें।

**Build was configured to prefer settings repositories**
`app/build.gradle.kts` में से `repositories { }` हटाएँ। रिपॉज़िटरी सिर्फ़ `settings.gradle.kts` में रहनी चाहिए।

**Java heap space / OutOfMemoryError**
`gradle.properties` में `-Xmx2g` को `-Xmx4g` करें।

**Compose Compiler requires Kotlin version ...**
Kotlin प्लगइन और `org.jetbrains.kotlin.plugin.compose` प्लगइन का वर्शन एक जैसा रखें (अभी दोनों 2.0.20)।

**Manifest merger failed ... android:exported**
हर `<activity>` में `android:exported="true"` या `"false"` साफ़ लिखें।

**No files were found with the provided path: app/build/outputs/apk/debug/*.apk**
असली एरर इस स्टेप से पहले वाले स्टेप में है। ऊपर जाकर `Build Debug APK` का लॉग देखें। मॉड्यूल का नाम `app` से बदला हो तो `path` भी बदलें।

**Gemini: HTTP 404 / "models/... is not found"**
सेटिंग्स में Gemini मॉडल बदलकर `gemini-3.8-flash` करें। Google पुराने मॉडल (जैसे `gemini-2.5-flash`) हटाता रहता है, इसलिए मॉडल का नाम बदलना पड़ सकता है।

**Unresolved reference: Presentation / Transformer / EditedMediaItem**
`app/build.gradle.kts` में तीनों `androidx.media3:media3-common`, `media3-effect`, `media3-transformer` (वर्शन 1.4.1) होने चाहिए, और तीनों का वर्शन एक ही रहे।

**Unit tests फेल (`LogicTest`)**
लॉग में फेल हुए टेस्ट का नाम दिखेगा। वह टेस्ट और उससे जुड़ी फ़ाइल (Planner.kt, Slicer.kt, Pexels.kt, ClipsPipeline.kt) मुझे भेज दें।

**फ़ोन पर: ExportException (Decoding/Encoder failed)**
फ़ोन किसी क्लिप का फ़ॉर्मेट या साइज़ सँभाल नहीं पाया। छोटा वीडियो या आड़ा 16:9 आज़माएँ, और ऐप में लिखा एरर मुझे भेजें।

**फ़ोन पर: "आवाज़ इंस्टॉल नहीं है"**
फ़ोन की Settings में Text-to-speech खोलकर Hindi (hi-IN) आवाज़ डाउनलोड करें, या आवाज़ का स्रोत `elevenlabs` करें।

**Release बनाते समय `Resource not accessible by integration` या 403**
Settings → Actions → General → **Workflow permissions** में **Read and write permissions** चुनें।

**Android SDK licences accepted नहीं (आमतौर पर GitHub रनर पर नहीं आता)**
बिल्ड स्टेप से पहले यह स्टेप जोड़ें:
```yaml
- run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses || true
```

## 4. APK कहाँ मिलेगा

- **हर पुश पर:** Actions → रन → नीचे **Artifacts → autovideo-debug-apk**।
- **रिलीज़ पर:** `git tag v1.0 && git push origin v1.0` चलाएँ। APK रिपो के **Releases** में लग जाएगा।
